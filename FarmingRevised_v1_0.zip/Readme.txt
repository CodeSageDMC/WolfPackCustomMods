﻿This is the mod for Farming Consolidated.
Changes everything that was GatheringSkill or Fertilizers Skill, into Farming Skill.

To install, extract zip file, and everything in Usercode into your servers Mods/UserCode folder.  
That means all of the Autogen, Player, and Systems folders must be in your UserCode folder for the overrides to work.
