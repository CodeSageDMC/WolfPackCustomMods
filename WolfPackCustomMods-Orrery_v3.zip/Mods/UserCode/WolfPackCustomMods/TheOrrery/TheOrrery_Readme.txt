﻿This is the mod, Orrery.

To install, unzip files, place in your server 'UserCode' folder in 'Mods'.
Thats the WolfPackCustomMods placed into the UserCode folder.

To update, remove the TheOrrery Folder, and then install.

Enjoy!