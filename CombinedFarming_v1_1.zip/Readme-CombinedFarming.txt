﻿This is the mod, Combined Farming, which takes everything that was Gathering Skill or Fertilizers Skill, and combines it into Farming Skill.

To install, extract zip file, and everything in Usercode into your servers Mods/UserCode folder.  
That means all of the Autogen, Player, and Systems folders must be in your UserCode folder for the overrides to work.
