﻿This is the mod, Eco420.

To install, unzip files, place in your server 'UserCode' folder in "Mods".
Thats the Autogen override and the WolfPackCustomMods placed into the UserCode folder.

Enjoy!