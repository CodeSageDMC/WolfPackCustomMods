// Copyright (c) Strange Loop Games. All rights reserved.
// See LICENSE file in the project root for full license information.

namespace Eco.Mods.TechTree
{
#pragma warning disable CA1416
    using Eco.Gameplay;
    using Eco.Gameplay.Components;
    using Eco.Gameplay.Components.Auth;
    using Eco.Gameplay.Explosions;
    using Eco.Gameplay.Objects;

    [RequireComponent(typeof(ExplosionComponent))]
    [RequireComponent(typeof(StatusComponent))]
    [RequireComponent(typeof(AuthComponent))]
    public partial class CreeperDynamiteObject : WorldObject
    {
        protected override void PostInitialize()
        {
            base.PostInitialize();
            this.GetComponent<ExplosionComponent>().Initialize(new ExplosionConfig()
            {
                ExplosionRadius = 5,
                FuseTime = 4,
                CraterRadius = 4,
                PollutionTons = 0.4f,
                CaloriesBurn = 300f,
                BlockFallConfig = new BlockFallConfig()
                {
                    Enabled = true,
                    BlockFilter = BlockFallProcessType.All,
                    IterationsMax = 50,
                    MovedDeltaMin = 4
                },
            });
        }
    }

}
